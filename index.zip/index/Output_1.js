console.log("bangladesh")
var x = 3, y = 4, z;
z = x + y
document.write("output of the variable : ", z)

subject = ["english", "math", "bangla"]


var x = prompt("please enter your name: ")
document.write("number of character : ", x.length, "index number :", x.)